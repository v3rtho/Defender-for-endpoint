

# =================================================================================================
#                                              Functions
# =================================================================================================

# Verifies that the script is running as admin
function Check-IsElevated
{
    $id = [System.Security.Principal.WindowsIdentity]::GetCurrent()
    $p = New-Object System.Security.Principal.WindowsPrincipal($id)

    if ($p.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator))
    {
        Write-Output $true
    }            
    else
    {
        Write-Output $false
    }       
}

# Verifies that script is running on Windows 10 or greater
function Check-IsWindows10
{
    if ([System.Environment]::OSVersion.Version.Major -ge "10" -and [System.Environment]::OSVersion.Version.Build -ge "16299")  
    {
        Write-Output $true
    }
    else
    {
        Write-Output $false
    }
}

# =================================================================================================
#                                              Main
# =================================================================================================
if (!(Check-IsElevated))
{
    throw "Please run this script from an elevated PowerShell prompt"            
}

if (!(Check-IsWindows10))
{
    throw "Please run this script on Windows 10"            
}

# =================================================================================================
# Disabling CFA
# =================================================================================================
Remove-MpPreference -ControlledFolderAccessProtectedFolders "c:\demo"
Set-MpPreference -EnableControlledFolderAccess Disabled

# =================================================================================================
# Disabling ASR rules
# =================================================================================================
Add-MpPreference -AttackSurfaceReductionRules_Ids BE9BA2D9-53EA-4CDC-84E5-9B1EEEE46550 -AttackSurfaceReductionRules_Actions Disabled
Add-MpPreference -AttackSurfaceReductionRules_Ids D4F940AB-401B-4EfC-AADC-AD5F3C50688A -AttackSurfaceReductionRules_Actions Disabled
Add-MpPreference -AttackSurfaceReductionRules_Ids 3B576869-A4EC-4529-8536-B80A7769E899 -AttackSurfaceReductionRules_Actions Disabled
Add-MpPreference -AttackSurfaceReductionRules_Ids 75668C1F-73B5-4CF0-BB93-3ECF5CB7CC84 -AttackSurfaceReductionRules_Actions Disabled
Add-MpPreference -AttackSurfaceReductionRules_Ids D3E037E1-3EB8-44C8-A917-57927947596D -AttackSurfaceReductionRules_Actions Disabled
Add-MpPreference -AttackSurfaceReductionRules_Ids 5BEB7EFE-FD9A-4556-801D-275E5FFC04CC -AttackSurfaceReductionRules_Actions Disabled
Add-MpPreference -AttackSurfaceReductionRules_Ids 92E97FA1-2EDF-4476-BDD6-9DD0B4DDDC7B -AttackSurfaceReductionRules_Actions Disabled
Add-MpPreference -AttackSurfaceReductionRules_Ids D1E49AAC-8F56-4280-B9BA-993A6D77406C -AttackSurfaceReductionRules_Actions Disabled
Add-MpPreference -AttackSurfaceReductionRules_Ids B2B3F03D-6A65-4F7B-A9C7-1C7EF74A9BA4 -AttackSurfaceReductionRules_Actions Disabled
Add-MpPreference -AttackSurfaceReductionRules_Ids C1DB55AB-C21A-4637-BB3F-A12568109D35 -AttackSurfaceReductionRules_Actions Disabled
Add-MpPreference -AttackSurfaceReductionRules_Ids 01443614-CD74-433A-B99E-2ECDC07BFC25 -AttackSurfaceReductionRules_Actions Disabled
Add-MpPreference -AttackSurfaceReductionRules_Ids 26190899-1602-49E8-8B27-EB1D0A1CE869 -AttackSurfaceReductionRules_Actions Disabled
Add-MpPreference -AttackSurfaceReductionRules_Ids 7674BA52-37EB-4A4F-A9A1-F0F9A1619A2C -AttackSurfaceReductionRules_Actions Disabled
# =================================================================================================
# Download cleanup program to c:\demo\CleanupTools
# =================================================================================================
$dirPath = "c:\demo"
$testCleanupToolsFileName = "ransomware_cleanup_encrypt_decrypt.exe"
$testCleanupToolsFolderName = "CleanupTools"
$targetCleanupToolsFolderPath = Join-Path -Path $dirPath -childPath $testCleanupToolsFolderName
$targetCleanupToolFilePath = Join-Path -Path $targetCleanupToolsFolderPath -childPath $testCleanupToolsFileName

if((Test-Path -Path $targetCleanupToolsFolderPath) -and (Test-Path -Path $targetCleanupToolFilePath)){ #Folder and cleanup tool file exist
	Write-Host "`nCleanup tools are already downloaded"  -ForegroundColor Green
}
else{
	if(!(Test-Path -Path $targetCleanupToolsFolderPath))
	{
		try{
			Write-Host "`nCreating c:\demo\CleanupTools folder"
			New-Item -ItemType directory -Path $targetCleanupToolsFolderPath 
		}
		catch {Write-Host "`nUnable to create c:\demo\CleanupTools folder"  -ForegroundColor Red}
	}
	else { 
		Write-Host "`nc:\demo\CleanupTools folder already exists"  -ForegroundColor Green 
	}
	
	if(!(Test-Path -Path $targetCleanupToolFilePath))
	{
		Write-Host "`nDownloading cleanup tool from https://demo.wd.microsoft.com/Content/ransomware_cleanup_encrypt_decrypt.exe"
		try{
			$url = 'https://demo.wd.microsoft.com/Content/ransomware_cleanup_encrypt_decrypt.exe'
			Invoke-WebRequest $url -OutFile $targetCleanupToolFilePath
			if(Test-Path -Path $targetCleanupToolFilePath){ #Check if cleanup tool was downloaded successfully
				Write-Host "`nCleaup tool was successfully downloaded"  -ForegroundColor Green
			}
		}
		catch{ Write-Host "`nUnable to download cleanup tool. Please download test file manually from the website here: https://demo.wd.microsoft.com/Page/CFA"  -ForegroundColor Red }
	}
}

# =================================================================================================
# Start decryption
# =================================================================================================
$encryptedFileName = "testfile_safe.txt.encrypted!"
$decryptedFileName = "testfile_safe.txt"
$encryptedFilePath = Join-Path -Path $dirPath -childPath $encryptedFileName
$decryptedFilePath = Join-Path -Path $dirPath -childPath $decryptedFileName

if(Test-Path -Path $encryptedFilePath){
	Write-Host "`nDecrypting files..."
	try {
		Start-Process -FilePath $targetCleanupToolFilePath
	}
	catch {Write-Host "`nUnable to decrypt the files. Please manually use cleanup tool or delete encrypted files."  -ForegroundColor Red}
	
	#Check if decryption was successful
	if(!(Test-Path -Path $decryptedFilePath) -and (Test-Path -Path $encryptedFilePath)){
		Write-Host "`nFiles were successfully decrypted."  -ForegroundColor Green 
	}
	else {
		Write-Host "`nUnable to decrypt the files. Please manually use cleanup tool or delete encrypted files." -ForegroundColor Red
	}
}
else {
	Write-Host "`nFiles are not decrypted."  -ForegroundColor Green 
}


exit 0